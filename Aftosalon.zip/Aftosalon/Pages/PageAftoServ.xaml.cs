﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Aftosalon.Classes;

namespace Aftosalon.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAftoServ.xaml
    /// </summary>
    public partial class PageAftoServ : Page
    {
        private AftoServ _currentAftoserv = new AftoServ();
        public PageAftoServ()
        {
            InitializeComponent();
            CMBafto.ItemsSource = AfroserviceEntities.GetContext().Afto.ToList();
            CMBservice.ItemsSource = AfroserviceEntities.GetContext().Service.ToList();
            CMBafto.SelectedValuePath = "Id_spisokafto";
            CMBafto.DisplayMemberPath = "Gosnomer";
            CMBservice.SelectedValuePath = "Id_spisokservice";
            CMBservice.DisplayMemberPath = "Services";
            DataContext = _currentAftoserv;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new GlavMenu());
        }

        private void Addser_Click(object sender, RoutedEventArgs e)
        {
            if (_currentAftoserv.Id_afroser == 0)
                AfroserviceEntities.GetContext().AftoServ.Add(_currentAftoserv);
            try
            {
                AfroserviceEntities.GetContext().SaveChanges();
                MessageBox.Show("Данные сохранены");
                ClassFrame.frmObj.Navigate(new PageAftoServ());

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}
