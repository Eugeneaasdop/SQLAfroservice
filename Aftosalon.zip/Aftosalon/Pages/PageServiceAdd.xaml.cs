﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Aftosalon.Classes;

namespace Aftosalon.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageServiceAdd.xaml
    /// </summary>
    public partial class PageServiceAdd : Page
    {
        private Service _currentService = new Service();
        public PageServiceAdd(Service selectedService)
        {
            InitializeComponent();
            if (selectedService != null)
            {
                _currentService = selectedService;
                Titletxt.Text = "Изменение услуги";
                btnAddService.Content = "Изменить";
            }
            // Создаём контекст
            DataContext = _currentService;
        }

        private void btnAddService_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentService.Services)) error.AppendLine("Укажите марку");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentService.Id_spisokservice == 0)
            {
                AfroserviceEntities.GetContext().Service.Add(_currentService);
                try
                {
                    AfroserviceEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageService());
                    MessageBox.Show("Новая услуга успешна добавлена!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    AfroserviceEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageService());
                    MessageBox.Show("Услуга успешна изменена!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageService());
        }
    }
}
