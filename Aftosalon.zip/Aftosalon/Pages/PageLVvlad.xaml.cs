﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Aftosalon.Classes;
using Excel = Microsoft.Office.Interop.Excel;

namespace Aftosalon.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageLVvlad.xaml
    /// </summary>
    public partial class PageLVvlad : Page
    {
        public PageLVvlad()
        {
            InitializeComponent();
            var currentvlad = AfroserviceEntities.GetContext().Vlad.ToList();
            DataContext = LViewVlad;
            CmbFiltr.Items.Add("Все телефоны");
            foreach (var item in AfroserviceEntities.GetContext().Vlad.
                Select(x => x.Telefon).Distinct().ToList())
                CmbFiltr.Items.Add(item);
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            string search = TxtSearch.Text;
            if (TxtSearch.Text != null)
            {
                LViewVlad.ItemsSource = AfroserviceEntities.GetContext().Vlad.
                    Where(x => x.Surname.Contains(search)
                    || x.Name.Contains(search)
                    || x.Telefon.ToString().Contains(search)).ToList();
            }
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            LViewVlad.ItemsSource = AfroserviceEntities.GetContext().Vlad.
                OrderBy(x => x.Surname).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            LViewVlad.ItemsSource = AfroserviceEntities.GetContext().Vlad.
                OrderByDescending(x => x.Surname).ToList();
        }

        private void CmbFiltr_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbFiltr.SelectedValue.ToString() == "Все телефоны")
            {
                LViewVlad.ItemsSource = AfroserviceEntities.GetContext().Vlad.ToList();
                //TxbCountSearchItem.Text = dbISP19AEntities.GetContext().User.Count().ToString();
            }
            else
            {
                LViewVlad.ItemsSource = AfroserviceEntities.GetContext().Vlad.
                    Where(x => x.Telefon == CmbFiltr.SelectedValue.ToString()).ToList();
            }
        }

        private void BtnSaveToExcel_Click(object sender, RoutedEventArgs e)
        {
            var app = new Excel.Application();

            //книга 
            Excel.Workbook wb = app.Workbooks.Add();
            //лист
            Excel.Worksheet worksheet = app.Worksheets.Item[1];
            int indexRows = 1;
            //ячейка
            worksheet.Cells[1][indexRows] = "Номер";
            worksheet.Cells[2][indexRows] = "Фамилия";
            worksheet.Cells[3][indexRows] = "Имя";
            worksheet.Cells[4][indexRows] = "Телефон";
            //список пользователей
            var printItems = AfroserviceEntities.GetContext().Vlad.ToList();
            //цикл по данным из таблицы
            foreach (var item in printItems)
            {
                worksheet.Cells[1][indexRows + 1] = indexRows;
                worksheet.Cells[2][indexRows + 1] = item.Surname;
                worksheet.Cells[3][indexRows + 1] = item.Name;
                worksheet.Cells[4][indexRows + 1] = item.Telefon.ToString();
                indexRows++;
            }

            //показать Excel
            app.Visible = true;
        }

        private void BtnSaveToExcelTemplate_Click(object sender, RoutedEventArgs e)
        {
            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook wb = excelApp.Workbooks.Open($"{Directory.GetCurrentDirectory()}\\Shablon.xlsx");
            Excel.Worksheet ws = (Excel.Worksheet)wb.Worksheets[1];
            ws.Cells[1, 4] = "Автосалон";
            ws.Cells[4, 1] = "Дата";
            DateTime date = new DateTime(2022, 1, 1, 18, 30, 10);
            ws.Cells[4, 2] = date.ToShortDateString();
            int indexRows = 6;
            //ячейка
            ws.Cells[1][indexRows] = "Номер";
            ws.Cells[2][indexRows] = "Фамилия";
            ws.Cells[3][indexRows] = "Имя";
            ws.Cells[4][indexRows] = "Телефон";

            //список пользователей из таблицы после фильтрации и поиска
            var printItems = LViewVlad.Items;
            //цикл по данным из списка для печати
            foreach (Vlad item in printItems)
            {
                ws.Cells[1][indexRows + 1] = indexRows;
                ws.Cells[2][indexRows + 1] = item.Surname;
                ws.Cells[3][indexRows + 1] = item.Name;
                ws.Cells[4][indexRows + 1].Value = item.Telefon.ToString();

                indexRows++;
            }
            ws.Cells[indexRows + 2, 3] = "Подпись";
            ws.Cells[indexRows + 2, 4] = "Серебрянников Е.А.";
            excelApp.Visible = true;
        }

        private void Glav_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new GlavMenu());
        }
    }
}
