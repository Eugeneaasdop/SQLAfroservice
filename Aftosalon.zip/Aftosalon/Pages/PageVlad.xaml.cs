﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Aftosalon.Classes;

namespace Aftosalon.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageVlad.xaml
    /// </summary>
    public partial class PageVlad : Page
    {
        public PageVlad()
        {
            InitializeComponent();
            DtgSQL.ItemsSource = AfroserviceEntities.GetContext().Vlad.ToList();
            CMBFilterTel.ItemsSource = AfroserviceEntities.GetContext().Vlad.ToList();
            CMBFilterTel.SelectedValuePath = "Id_vlad";
            CMBFilterTel.DisplayMemberPath = "Telefon";
            //CMBFilterAquar.Items.Add("От 10 до 100");
            //CMBFilterAquar.Items.Add("От 101 до 500");
            //CMBFilterAquar.Items.Add("От 501 до 1000");
        }

        private void BTNedit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageVladAdd((Vlad)DtgSQL.SelectedItem));
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            CMBFilterTel.SelectedItem = null;
            DtgSQL.ItemsSource = AfroserviceEntities.GetContext().Vlad.ToList();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new GlavMenu());
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAfto());
        }

        private void CMBFilterTel_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int ID = Convert.ToInt32(CMBFilterTel.SelectedValue);
            DtgSQL.ItemsSource = AfroserviceEntities.GetContext().Vlad.Where(x => x.Id_vlad == ID).ToList();
            //if (CMBFilterFish.SelectedIndex == 0)
            //    DtgSQL.ItemsSource = PetShopEntities.GetContext().Fish.Where(x => x.Price >= 10 && x.Price <= 100).ToList();
            //else if (CMBFilterFish.SelectedIndex == 1)
            //    DtgSQL.ItemsSource = PetShopEntities.GetContext().Fish.Where(x => x.Price >= 101 && x.Price <= 500).ToList();
            //else
            //    DtgSQL.ItemsSource = PetShopEntities.GetContext().Fish.Where(x => x.Price >= 501 && x.Price <= 1000).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DtgSQL.ItemsSource = AfroserviceEntities.GetContext().Vlad.OrderByDescending(x => x.Surname).ToList();
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DtgSQL.ItemsSource = AfroserviceEntities.GetContext().Vlad.OrderBy(x => x.Surname).ToList();
        }

        private void FindFIO_TextChanged(object sender, TextChangedEventArgs e)
        {
            DtgSQL.ItemsSource = AfroserviceEntities.GetContext().Vlad.Where(x => x.Surname.ToLower().Contains(FindFIO.Text.ToLower())).ToList();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageService());
        }

        private void Delette_Click(object sender, RoutedEventArgs e)
        {
            var VladForRemoving = DtgSQL.SelectedItems.Cast<Vlad>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {VladForRemoving.Count()} записи?", "Внимание",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    AfroserviceEntities.GetContext().Vlad.RemoveRange(VladForRemoving);
                    AfroserviceEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DtgSQL.ItemsSource = AfroserviceEntities.GetContext().Vlad.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }
        private void Add_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageVladAdd(null));
        }
    }
}
